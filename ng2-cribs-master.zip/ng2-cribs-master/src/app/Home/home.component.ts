import { Component } from '@angular/core';

@Component({

  template: `
   
   
   <div class="container">
  <app-add-listing-form></app-add-listing-form>
  <app-crib-listing></app-crib-listing>
    </div> `,

})
export class HomeComponent {
  
}
