import { Component } from '@angular/core';

@Component({

  template:`<h1> github fgfdg  ff</h1>`
})
export class GitHubAboutComponent {
pageHometitle:string ="NGCribs";
}
