
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import{NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import{RouterModule} from '@angular/router';


import{ GitHubRoutingModule} from '../GitHub Services/github.routing';

//import {SharedModule} from '../shared/shared.module';
import {GitHubSearchComponent} from '../GitHub Services/githubsearch.component';
import{ GitHubAboutComponent} from './Githubabout/githubabout.component';
 import{GitHUBSearchService } from '../GitHub Services/githubsearchservice';




@NgModule({


imports:[//SharedModule,
    
    CommonModule,
    BrowserModule,GitHubRoutingModule
],declarations:[GitHubAboutComponent,GitHubSearchComponent],

providers:[GitHUBSearchService]


})

export class GitHubModule{}