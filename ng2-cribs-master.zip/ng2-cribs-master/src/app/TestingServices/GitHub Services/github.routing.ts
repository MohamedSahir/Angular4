import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import{GitHubSearchComponent } from '../GitHub Services/githubsearch.component';


import{ GitHubAboutComponent} from './Githubabout/githubabout.component';
const searchRoutes: Routes = [

    {path:'githubservice',component:GitHubSearchComponent,

children:[

    {path:'githubserviceabout',component:GitHubAboutComponent}]



},
    
   

]

@NgModule({
    imports: [ RouterModule.forChild(searchRoutes) ],
    exports: [ RouterModule ]
  })
  export class GitHubRoutingModule{ } 

