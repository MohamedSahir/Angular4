import { Component,OnInit } from '@angular/core';
// import {ProductService} from './product.service';
// import {IProduct} from './product';


import {GitHUBSearchService} from './githubsearchservice';
@Component({
  selector: 'app-search',
  //template:`<h1>products</h1> 
templateUrl:'github.search.html',
providers:[GitHUBSearchService]



})
export class GitHubSearchComponent implements OnInit {


public searchText;public searchResult;public searchCount;

constructor(private _githubService:GitHUBSearchService){}

 
ngOnInit(){}
onKeyUp(event)
{

this.searchText = event.target.value;

}

getUsers(){
this._githubService.getUser(this.searchText).subscribe
(
res => {    
this.searchResult = res;
this.searchCount =res.total_count;
console.log(res);
}
)
}
}