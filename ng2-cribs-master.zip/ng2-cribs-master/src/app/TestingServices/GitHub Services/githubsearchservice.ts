import { Injectable,Inject } from '@angular/core';  

import {Http,Response} from '@angular/http';
import{Observable} from 'rxjs/Rx';


@Injectable()  
export class GitHUBSearchService {  
  
constructor(@Inject(Http) private _http:Http){

}

getUser(searchText) :Observable<any>{
const Url = 'http://api.github.com/search/users?q=' + searchText;
return this._http.get(Url).map(res => { const data = res.json();console.log(data); return data; })
}



}   