export interface CarParts{
 
id :string,name:string,description:string,IsInStock:number,Price:number
}