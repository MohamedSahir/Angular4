import { Component } from '@angular/core';
import {Router} from '@angular/Router';
@Component({

  template:`<h1> Service About Page  </h1> <button class="btn btn-info" (click)='onBack()'>OnBack</button>`
})
export class ServiceAboutComponent {
pageHometitle:string ="NGCribs";


constructor(private _router :Router){}


onBack():void{

    this._router.navigate(['/services']);
}

}
