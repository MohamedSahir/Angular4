import { Injectable } from '@angular/core';  

@Injectable()  
export class MyService {  
  GetText() {  
      return "Text From Service";  
  }  
}  