import {Http} from '@angular/http';
import'rxjs/add/operator/map';
import { Injectable } from '@angular/core';  
import {CarParts} from './Models/carparts';

@Injectable()  
export class RacingService {  

constructor(private http :Http)
{}

getCarParts(){
return this.http.get('data/car-parts.json').map(response => <CarParts[]> response.json().data);
}



}  