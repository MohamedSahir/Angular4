import { Component } from '@angular/core';
import {MyService} from './Services/simple.service';
import {RacingService} from './Services/simple1.services';
import {CarParts} from './Services/Models/carparts';


@Component({
  template: `<p>welcome to services test page</p> : Click the Button and see the Changes:  <p>{{ messageText}}</p>
  <button class ="btn btn-danger" (click) ='myFunction()'> simple services</button>
  <button class ="btn btn-danger" (click) ='simpleservices1()'> simple services1 </button>
  
  <input type ="text" #textInput value="{{text}}">
  <table>
  <tr *ngFor = 'let product of CarParts '>
    <td>{{product.name}}</td>
    <td>{{product.Id}}</td><td>{{product.description}}</td>
    <td><button type="button" class="btn btn-default">Edit</button>
  </tr> 
</table>
<a [routerLink] ="['githubservice/githubserviceabout']">Aboutfdsfdsfsd</a>
<router-outlet></router-outlet>

  `,

  providers:[MyService,RacingService]

})
export class TestingComponent {
  
    messageText:string=''; text:string='';
     CarParts:CarParts[];

constructor(private _myService:MyService , private _racingService:RacingService){




}


myFunction(){alert('service1 tested');

this.messageText = this._myService.GetText();   }


simpleservices1(){

this._racingService.getCarParts().subscribe(CarParts => console.log(this.CarParts = CarParts));


}






}
