import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

//for Routings
import {RouterModule} from '@angular/Router';
import {AppRoutesModule} from './app.routes';

import {ProductModule} from './products/product.module';

//starts Range of Ng2-cribs 


import { AppComponent } from './app.component';
import { CribListingComponent } from './crib-listing/crib-listing.component';
import { CribCardComponent } from './crib-card/crib-card.component';
import { AddListingFormComponent } from './add-listing-form/add-listing-form.component';

import { CribsService } from './services/cribs.service';
import { UtilService } from './services/util.service';
import { SortByPipe } from './pipes/sort-by.pipe';

//End 
import { TestingComponent } from './TestingServices/testing.component';
import{HomeComponent} from './Home/home.component';
import {GitHubModule} from './TestingServices/GitHub Services/github.module';
import {ServiceAboutComponent} from './TestingServices/Services/serviceabout.component';
@NgModule({

  imports: [
    BrowserModule,
    FormsModule,ProductModule,GitHubModule,
    HttpModule,AppRoutesModule
  ],

  declarations: [
    AppComponent,HomeComponent,
    CribListingComponent,
    CribCardComponent,
    AddListingFormComponent,TestingComponent,ServiceAboutComponent,
    SortByPipe
  ],
  
  providers: [
    CribsService,
    UtilService
  ],
  // exports:[RouterModule],

  bootstrap: [AppComponent]
})
export class AppModule { }
