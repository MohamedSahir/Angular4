import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {Routes,RouterModule,Router} from '@angular/router';

// Declare the respective component for Routes
import { AppComponent } from './app.component';import{HomeComponent} from './Home/home.component';
import { TestingComponent } from './TestingServices/testing.component';
import {ServiceAboutComponent} from './TestingServices/Services/serviceabout.component';
 const routes : Routes=[

{path:'',component:TestingComponent},

{path:'services',component:TestingComponent,


children:[
    
        {path:'serviceabout',component:ServiceAboutComponent}]


},


{path:'home',component:HomeComponent},
]

@NgModule({
    imports: [ 
            RouterModule.forRoot(routes) 
    ],
    exports: [ 
            RouterModule 
    ]
  })
  export class AppRoutesModule{ } 