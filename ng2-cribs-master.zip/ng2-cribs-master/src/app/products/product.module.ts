
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import{NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import{RouterModule} from '@angular/router';


import{ ProductRoutingModule} from '../products/product.routing';

//import {SharedModule} from '../shared/shared.module';
import{ProductListComponent} from '../products/productlist.component';

 import{ProductService} from './product.service';




@NgModule({


imports:[//SharedModule,
    
    CommonModule,
    BrowserModule,ProductRoutingModule
],declarations:[ProductListComponent],

providers:[ProductService]


})

export class ProductModule{}