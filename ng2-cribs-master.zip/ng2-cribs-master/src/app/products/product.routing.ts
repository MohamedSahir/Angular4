import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import{ProductListComponent} from '../products/productlist.component';
const productRoutes: Routes = [

    {path:'products',component:ProductListComponent}


]

@NgModule({
    imports: [ RouterModule.forChild(productRoutes) ],
    exports: [ RouterModule ]
  })
  export class ProductRoutingModule{ } 

