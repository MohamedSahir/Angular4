export interface IProduct{
productID:number;
productName:string;
price:number;
}