import { Component,OnInit } from '@angular/core';
import {ProductService} from './product.service';
import {IProduct} from './product';

@Component({
  selector: 'app-products',
  //template:`<h1>products</h1> 
templateUrl:'productslist.html'

})
export class ProductListComponent implements OnInit {
  
products :IProduct[];
errorMsg :string;

totalprice:number;

    constructor(private _productService:ProductService)
    
    {

    }

    ngOnInit():void{

        this._productService.getProducts().subscribe(products => console.log(this.products = products),
          err=> this.errorMsg =<any>err);
        
    }


getTotal(){let total = 0;
    for (let i = 0; i < this.products.length; i++) {
        if (this.products[i].price) {
            total += this.products[i].price;
            this.totalprice = total;
        }
    }
    return total;

}
}
