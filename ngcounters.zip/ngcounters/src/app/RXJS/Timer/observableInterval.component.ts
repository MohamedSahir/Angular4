import { Component ,OnInit,Input,Output,EventEmitter,OnChanges,OnDestroy} from '@angular/core';


import{EnergyService} from '../../services/windservices';
import{IEnergy} from '../../models/Energy'; import { Observable } from "rxjs";
import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import 'rxjs/add/operator/takeWhile';
import 'rxjs/add/operator/first';
@Component({
  selector: 'simple-canvas',
  templateUrl: './observableInterval.component.html',
   styleUrls:['./observableTimer.css']

 
})
export class OnservableTimerComponent  implements OnInit,OnDestroy{

   //https://stackoverflow.com/questions/41863514/how-to-set-an-inteval-on-angular-2-http-observable-request
    private timerSubscription: any;

    private data: IEnergy[];

    private display: boolean;

    private alive: boolean;

errorMsg;

    firstChartValue;
    constructor(private _energyService:EnergyService){

        this.display = false;
        this.alive = true;

  }
ngOnInit(){
//https://stackoverflow.com/questions/35316583/angular2-http-at-an-interval
    this._energyService.getEnergy()
    .first() // only gets fired once
    .subscribe((data) =>{
    
        
    this.data = data;
     this.firstChartValue = this.data[0].EnergyValue;
    }
    //  console.log("first" + new Date());
    //   this.display = true;

,(error) => {
if(error.status == 404){
console.log("error 404");


this.firstChartValue = 10;

}
else{

    console.log("error");

}

}

);
   
    // }),(err)=> {
    //     // alert(err);
    //     // if(err == "401"){
    //     // this.firstChartValue=100;
    //     // }
    // console.log(err);
    // };

    // IntervalObservable.create(10000)
    // .takeWhile(() => this.alive) // only fires when component is alive
    // .subscribe(() => {
    //     this._energyService.getEnergy()
    //     .subscribe(data => {
    //       this.data = data;  
          
    //       console.log(this.data);
    //       console.log(new Date());

    //     //   this.firstChartValue = this.data[1].EnergyValue;
    //     });
    // }),(err)=> {
    //   console.log(err);
    //     // if(err == "401"){
    //     // this.firstChartValue=200;
    //     // }
    
    // };


   



}


ngOnDestroy(){

    alert("destroyed");
    this.alive = false; // switches your IntervalObservable off
  }

}