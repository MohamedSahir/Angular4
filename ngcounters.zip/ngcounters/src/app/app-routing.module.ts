
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
 
// import { BikeInfoComponent } from '../bike-info/bike-info.component';
// import { BikesComponent } from '../bikes/bikes.component';
 
import { AppComponent } from './app.component';

import{RootParentComponent} from './rootparent.component';
import { SimpleCanvasComponent } from './canvas/simplecanvas.component';

import { BikeInfoComponent } from './bikes/bike-info.component';
import { BikesComponent } from './bikes/bikes.component';
import { PipesComponent } from './pipescomponent/pipes.component';
import { OnservableTimerComponent } from './RXJS/Timer/observableInterval.component';
import{CacheComponent} from './cacheSorage/cache.component';
import { LocalStorageComponent }  from './localstorage/localstorage.component';
const routes: Routes = [
 // { path: 'information/:id', component: BikeInfoComponent },
  { path: 'home', component: SimpleCanvasComponent},  { path: 'parentchild', component: RootParentComponent},

  { path: 'information/:id', component: BikeInfoComponent },
  { path: 'bikes', component: BikesComponent },
  { path: 'pipes', component: PipesComponent },
  { path: 'storages', component: LocalStorageComponent },
  { path: 'rxjsTimer', component: OnservableTimerComponent },
  { path: 'cache', component: CacheComponent },


];
 
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }