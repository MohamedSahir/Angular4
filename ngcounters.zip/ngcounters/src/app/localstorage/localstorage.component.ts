import { Component ,OnInit,Input,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'local-storage',
  templateUrl: './localstorage.component.html'
 
})
export class LocalStorageComponent implements OnInit {
    filter:string;
    storageKey:string;
     newValue;
     newValues;
     IntervalId;

setlocalStoargeKey;
getlocalStoargeKey;


constructor(){


}
ngOnInit(){
    console.log(new Date());

    let stores; 
    this.getlocalStoargeKey = window.localStorage.getItem("names");

    this.newValues = window.sessionStorage.getItem("names"); 
    if(stores == null)

    {

        alert('session storage is null');
    }else{
    stores=  window.sessionStorage.setItem("names","sahirr");


    this.newValues = window.sessionStorage.getItem("names");   
    }
    if(this.getlocalStoargeKey ==null){
        alert("there is no local storage set in this name");
   
    }else{ this.getlocalStoargeKey = window.localStorage.getItem("names");}

    this.onGetRefresh();
}

getcall()
{
  alert(1);
  this.storageKey='filter'; 
  let StoreValue=window.sessionStorage.getItem(this.storageKey);
  let store=  window.sessionStorage.setItem("name","sahir");
  this.newValue = window.sessionStorage.getItem("name");  
  
  // this.cd.detectChanges();
  console.log(this.newValue);
 
  // newValue= window.sessionStorage.setItem("names",StoreValue);
}

onGetRefresh(){
    alert("d");
    this.IntervalId= setInterval(() => {
      let stores=  window.sessionStorage.setItem("names","Sahir Interval");
      this.newValues = window.sessionStorage.getItem("names"); 
      console.log(new Date());
      
      }, 5000);
  }



LocalStoragecall(){

this.setlocalStoargeKey = window.localStorage.setItem("names","sahirLocalStorgae");
this.getlocalStoargeKey = window.localStorage.getItem("names");

}
ClearLocalStoragecall(){

    window.localStorage.removeItem("names");
}
}