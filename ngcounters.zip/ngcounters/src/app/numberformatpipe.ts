import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'numberformat'})

export class NumberFormatPipe implements PipeTransform {
    transform(value: string): string {
        if (!value) {
           return '';
        }
        return value.replace(',', '');
    }
}

// import { Pipe, PipeTransform } from '@angular/core';

// @Pipe({name: 'numberformat'})
// export class NumberFormatPipe implements PipeTransform {
//  transform(value: number): number {
//     return ...;
//   }
// }